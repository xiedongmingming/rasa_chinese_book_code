# Issus and fixes

## socketio channel in Rasa 3.0 is not working

```bash
pip install sanic==21.6.0
pip install Sanic-Cors==1.0.0
pip install sanic-routing==0.7.0
```
