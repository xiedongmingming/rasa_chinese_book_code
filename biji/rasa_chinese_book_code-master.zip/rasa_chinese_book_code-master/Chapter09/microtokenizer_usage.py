import MicroTokenizer

tokens = MicroTokenizer.cut("知识就是力量")
print(tokens)
